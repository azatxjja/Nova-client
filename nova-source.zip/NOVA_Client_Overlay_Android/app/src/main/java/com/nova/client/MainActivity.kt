package com.nova.client

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.view.Gravity

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(24))
            setBackgroundColor(Color.rgb(22, 16, 19))
        }
        val title = TextView(this).apply {
            text = "NOVA CLIENT"
            textSize = 30f
            setTextColor(Color.rgb(239, 65, 83))
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "OVERLAY FOR MINECRAFT BEDROCK"
            textSize = 12f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(28))
        }
        val status = TextView(this).apply {
            text = "Сначала разреши отображение поверх других приложений."
            textSize = 13f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(18), 0, 0)
        }
        val start = Button(this).apply {
            text = "ВКЛЮЧИТЬ OVERLAY"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName"))
                    startActivity(i)
                } else {
                    startForegroundService(Intent(this@MainActivity, OverlayService::class.java))
                    status.text = "NOVA активен. Открой Minecraft — плавающая кнопка останется поверх игры."
                }
            }
        }
        val play = Button(this).apply {
            text = "ЗАПУСТИТЬ MINECRAFT"
            setOnClickListener { launchMinecraft() }
        }
        layout.addView(title)
        layout.addView(subtitle)
        layout.addView(start, LinearLayout.LayoutParams(-1, dp(52)))
        layout.addView(play, LinearLayout.LayoutParams(-1, dp(52)))
        layout.addView(status)
        setContentView(layout)
    }

    private fun launchMinecraft() {
        val launch = packageManager.getLaunchIntentForPackage("com.mojang.minecraftpe")
        if (launch != null) startActivity(launch)
        else android.widget.Toast.makeText(this, "Minecraft Bedrock не найден. Установи игру официально.", android.widget.Toast.LENGTH_LONG).show()
    }
}
