package com.nova.client

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.*
import android.graphics.drawable.GradientDrawable

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private val active = mutableSetOf<String>()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createChannel()
        val notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, "nova_overlay")
                .setContentTitle("NOVA Client работает")
                .setContentText("Плавающее меню доступно поверх игры")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("NOVA Client работает")
                .setContentText("Плавающее меню доступно поверх игры")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .build()
        }
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(7, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else startForeground(7, notification)
        showBubble()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("nova_overlay", "NOVA Overlay", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun params(x: Int, y: Int): WindowManager.LayoutParams =
        WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; this.x = x; this.y = y }

    private fun bg(color: Int, radius: Float = 18f): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
        }

    private fun showBubble() {
        val b = TextView(this).apply {
            text = "N"
            textSize = 22f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            background = bg(Color.rgb(220, 48, 68), 28f)
            setOnClickListener { togglePanel() }
        }
        bubble = b
        val p = params(dp(18), dp(180)).apply { width = dp(54); height = dp(54) }
        b.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=p.x; oy=p.y; moved=false; return true }
                    MotionEvent.ACTION_MOVE -> {
                        val dx=(e.rawX-sx).toInt(); val dy=(e.rawY-sy).toInt()
                        if (kotlin.math.abs(dx)+kotlin.math.abs(dy)>dp(5)) moved=true
                        p.x=ox+dx; p.y=oy+dy; wm.updateViewLayout(b,p); return true
                    }
                    MotionEvent.ACTION_UP -> { if (!moved) togglePanel(); return true }
                }
                return false
            }
        })
        wm.addView(b, p)
    }

    private fun togglePanel() {
        if (panel != null) { closePanel(); return }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(14))
            background = bg(Color.rgb(29, 21, 25), 20f)
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(label("NOVA CLIENT", 18f, Color.rgb(245, 70, 88), true), LinearLayout.LayoutParams(0, dp(42), 1f))
        val close = Button(this).apply { text = "×"; setOnClickListener { closePanel() } }
        header.addView(close, LinearLayout.LayoutParams(dp(46), dp(42)))
        root.addView(header)
        root.addView(label("OVERLAY • BEDROCK", 10f, Color.LTGRAY))
        addToggle(root, "Coordinates HUD", "coords")
        addToggle(root, "World clock HUD", "clock")
        addToggle(root, "Entity counter (demo)", "entities")
        root.addView(label("Эти переключатели — демонстрационные настройки интерфейса.", 10f, Color.LTGRAY).apply {
            setPadding(0, dp(8), 0, dp(8))
        })
        val play = Button(this).apply {
            text = "PLAY MINECRAFT"
            setOnClickListener {
                val i = packageManager.getLaunchIntentForPackage("com.mojang.minecraftpe")
                if (i != null) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i) }
                else Toast.makeText(this@OverlayService, "Minecraft Bedrock не найден", Toast.LENGTH_SHORT).show()
            }
        }
        root.addView(play, LinearLayout.LayoutParams(-1, dp(46)))
        panel = root
        val p = params(dp(18), dp(250)).apply { width = dp(300) }
        panelParams = p
        try { wm.addView(root, p) } catch (_: Exception) { panel = null }
    }

    private fun addToggle(root: LinearLayout, title: String, key: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(4), dp(4), dp(4))
            background = bg(Color.rgb(48, 35, 40), 12f)
        }
        row.addView(label(title, 13f, Color.WHITE), LinearLayout.LayoutParams(0, dp(44), 1f))
        val sw = Switch(this).apply {
            isChecked = active.contains(key)
            setOnCheckedChangeListener { _, checked ->
                if (checked) active.add(key) else active.remove(key)
            }
        }
        row.addView(sw)
        val lp = LinearLayout.LayoutParams(-1, dp(48)); lp.topMargin = dp(7)
        root.addView(row, lp)
    }

    private fun closePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
    }

    override fun onDestroy() {
        closePanel()
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
