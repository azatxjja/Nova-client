NOVA CLIENT OVERLAY — Android Studio project

Что это:
Отдельное Android-приложение с плавающей кнопкой/меню поверх других приложений.
Кнопка PLAY пытается открыть установленный Minecraft Bedrock (пакет com.mojang.minecraftpe).

Важно:
- Это исходный проект, а не готовый APK.
- Переключатели HUD в этой первой сборке являются демонстрационными UI-настройками.
- Приложение НЕ внедряет код в Minecraft и не реализует Fullbright/Hitbox/Replay.
- Для показа поверх игры Android попросит разрешение "Отображение поверх других приложений".
- Android может показывать постоянное уведомление, пока overlay работает.

Как собрать APK:
1. Установи Android Studio на компьютер.
2. Распакуй ZIP.
3. Открой папку NOVA_Client_Overlay_Android в Android Studio.
4. Дождись синхронизации Gradle.
5. Build -> Build Bundle(s) / APK(s) -> Build APK(s).
6. APK будет в app/build/outputs/apk/debug/app-debug.apk

Минимум: Android 6.0 (API 23). Целевая сборка: Android 14 (API 34), compile SDK 35.
